FormValudator = function () {

};

// tooltips
FormValudator._MSG = {};
FormValudator._MSG["TITLE_OF_FIELD"] = "The <_TITLE_OF_FIELD_> is a required field!\n";
        
