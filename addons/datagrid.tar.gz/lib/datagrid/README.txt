THANK YOU FOR USING PHP BUILDER software!
-----------------------------------------------------------------------------------

It's very easy to get started!!!

1. Installation:
-- (not updated) docs/install.html 
-- (updated) http://phpbuilder.awardspace.com/dgwiki/installation.htm

2. Getting started:
-- (not updated) docs/getting started.html 
-- (updated) http://phpbuilder.awardspace.com/dgwiki/getting_started.htm


If you have any troubles, find an example of code in the folder, named "examples" 
-----------------------------------------------------------------------------------
For more information visit: 
	site 	http://phpbuilder.blogspot.com or 
	forum 	http://www.phpbb88.com/phpbuilder/


How You Can Help the PHP Builder Project
-----------------------------------------------------------------------------------
1. Write documentation for PHP DataGrid and/or JS AFV. 
2. Create a new CSS style for PHP DataGrid. 
3. Translate the PHP DataGrid and/or JS AFV into other languages. 
4. Translate the documentation for PHP DataGrid and/or JS AFV into other languages. 
5. Tell others about the PHP Builder Project by: 
   5.1 informing your friends about the PHP Builder Project and software. 
   5.2 adding a link of your web page, where the software was implemented on our live sites forum. 
       http://www.phpbb88.com/phpbuilder/viewforum.php?f=6&mforum=phpbuilder
6. Becoming an active member/moderator of the PHP Builder forum. 
7. Developmenting your own module and/or improving existing code for PHP DataGrid and/or JS AFV. 
8. Write documentation for PHP Builder software. 
9. Promote the PHP Builder software on other web sites. 
10.Write your testimonials:
   http://www.phpbb88.com/phpbuilder/viewforum.php?f=10&mforum=phpbuilder
11.Donate the PHP Builder Project. 
   http://phpbuilder.blogspot.com/2007/03/support-php-builder-make-donation.html   
12.Digg it! http://phpbuilder.blogspot.com
