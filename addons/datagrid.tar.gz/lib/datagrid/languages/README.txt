// Languages: if you found any word, that is not translated in your opinion -
//        please send your variant of translation to leumas.a@gmail.com
//        or simply post it on the forum:
//        http://www.phpbb88.com/phpbuilder/viewtopic.php?t=56&mforum=phpbuilder
//
// --- currently supported languages -------------------------------------------
//  1. (ar) Arabic 		         - provided by: Abdelmonim Osman 
//  2. (bg) Bulgarian
//  3. (ca) Catal�
//  4. (ch) Chinese
//  5. (cz) Czech                - provided by: Vojt&#283;ch Kotou&am
//  5. (de) German 		         - provided by: zewa666 http://www.thorax-music.com
//  6. (en) English
//  7. (es) Espa�ol
//  8. (fr) Fran�ais 
//  9. (hu) Hungarian 
// 10. (hr) Bosnian/Croatian     - provided by: zewa666 http://www.thorax-music.com
// 11. (it) Italiano             - provided by: Matteo Piotto <piotto@gmail.com> 
// 12. (nl) Netherlands / "Vlaams" (Flemish)
// 13. (pl) Polish  
// 14. (pb) Brazilian Portuguese - provided by: Julio Formiga <form1ga@yahoo.com.br>
// 15. (ro/ro_utf8) Romanian     - provided by: Rotter Robert <demon83ft@gmail.com>
// 15. (se) Swedish              - luckyluke
// 16. (sr) Serbian
// 17. (tr) Turkish              - provided by: Murat HALACOGLU <murat@halacoglu.com>
// -----------------------------------------------------------------------------